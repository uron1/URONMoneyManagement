
package uron;


public class PathManagement {

    //プロジェクトフォルダのパス
    public static String projectfolder ="/Volumes/uron/URON/アプリケーション/新URON Moeny Management/プロジェクト";
    

}
